﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace prg2
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
            textBox2.UseSystemPasswordChar = true;
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if(checkBox1.Checked)
            {
                textBox2.UseSystemPasswordChar = false;
            }
            else
            {
                textBox2.UseSystemPasswordChar = true;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string user, pass;
            user = textBox1.Text;
            pass = textBox2.Text;
            
            SqlConnection sqlcon=new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Admin\source\repos\prg2\prg2\Project.mdf;Integrated Security=True");
            String query = "Select email,password from Data where email='"+textBox1.Text+"' and password='"+textBox2.Text+"'";
            SqlDataAdapter sda = new SqlDataAdapter(query, sqlcon);
            DataTable dtbl = new DataTable();
            sda.Fill(dtbl);
            sqlcon.Close();
            if(dtbl.Rows.Count==1)
            {
                this.Hide();
                Form8 f8 = new Form8(user);
                f8.ShowDialog();
            }           
            else if (user == "admin" && pass == "admin")
                {
                try
                {
                    SqlConnection sc;
                    string ndate = DateTime.UtcNow.ToString("d");
                    sc = new SqlConnection();
                    sc.ConnectionString = (@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Admin\source\repos\prg2\prg2\Project.mdf;Integrated Security=True");
                    sc.Open();
                    string query1 = "select * from Reminder where date = '" + ndate + "'";
                    SqlCommand command = new SqlCommand(query1, sc);
                    SqlDataAdapter da = new SqlDataAdapter();
                    da.SelectCommand = command;
                    DataTable dt2 = new DataTable();
                    da.Fill(dt2);
                    foreach (DataRow row in dt2.Rows)
                    {
                        MessageBox.Show("Reminder : " + row[1].ToString() + " - " + row[2].ToString(), "Reminder");
                        String query2 = ("DELETE from Reminder WHERE date='" + ndate + "';");
                        SqlCommand cmd2 = new SqlCommand(query2, sc);
                        cmd2.ExecuteNonQuery();
                        sc.Close();
                    }
                }
                catch
                {

                }
                this.Hide();
                Form4 f4 = new Form4();
                f4.ShowDialog();
            }
            else
                {
                MessageBox.Show("Please check your username or password");
                }
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            this.Hide();
            Form3 f3 = new Form3();
            f3.ShowDialog();

        }

        private void button2_Click(object sender, EventArgs e)
        {
            string message = "Do you want to close this window ?";
            string title = "Close Window";
            MessageBoxButtons buttons = MessageBoxButtons.YesNo;
            DialogResult result = MessageBox.Show(message, title, buttons);
            if (result == DialogResult.Yes)
            {
                this.Close();
            }
            else
            {
                // Do something
            }
        }
    }
}
