﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace prg2
{
    public partial class Form9 : Form
    {
        string regno,str;
        SqlConnection sc;
        public Form9(String str)
        {
            InitializeComponent();
            regno = str;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            DialogResult fontResult = fontDialog1.ShowDialog();
            if (fontResult == DialogResult.OK)
            {
                richTextBox1.Font = fontDialog1.Font;
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if(saveFileDialog1.ShowDialog()==DialogResult.OK)
            {
                richTextBox1.SaveFile(saveFileDialog1.FileName);
            }
        }

        private void Form9_Load(object sender, EventArgs e)
        {
            comboBox1.Items.Add("MCA");
            comboBox1.Items.Add("MSC");
            comboBox2.Items.Add("1");
            comboBox2.Items.Add("2");
            DataRow dr;
            sc = new SqlConnection();
            sc.ConnectionString = (@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Admin\source\repos\prg2\prg2\Project.mdf;Integrated Security=True");
            sc.Open();
            richTextBox1.Text = "the mark will appear here!";
            richTextBox1.Enabled = false;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            String email = "";
            SqlCommand command;
            SqlDataAdapter da;
            SqlConnection connection = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Admin\source\repos\prg2\prg2\Project.mdf;Integrated Security=True");
            String query = "Select email from Data where regno='" + regno + "';";
            command = new SqlCommand(query, connection);
            da = new SqlDataAdapter();
            da.SelectCommand = command;
            DataTable dt = new DataTable();
            da.Fill(dt);
            foreach (DataRow row in dt.Rows)
            {
                email = (string)row[0];
            }
            da.Dispose();
            this.Hide();
            Form8 f8 = new Form8(email);
            f8.ShowDialog();
       }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            str = "";
            str = comboBox1.Text + comboBox2.Text;
            textBox1.Text = str;
        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            str = "";
            str = comboBox1.Text + comboBox2.Text;
            textBox1.Text = str;
        }
        void update1()
        {
            richTextBox1.Text = "";
            SqlCommand command;
            SqlDataAdapter da;
            SqlConnection connection = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Admin\source\repos\prg2\prg2\Project.mdf;Integrated Security=True");
            String query = "select * from information_schema.columns where table_name = '" + textBox1.Text + "' and column_name <> 'regno'";
            command = new SqlCommand(query, connection);
            da = new SqlDataAdapter();
            da.SelectCommand = command;
            DataTable dt = new DataTable();
            da.Fill(dt);
            listBox1.DataSource = dt;
            listBox1.DisplayMember = "Column_Name";
            da.Dispose();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            update1();
            update2();
        }

        void update2()
        { 
            SqlCommand command;
            SqlDataAdapter da;
            SqlConnection connection2 = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Admin\source\repos\prg2\prg2\Project.mdf;Integrated Security=True");
            string query = "select * from "+ textBox1.Text +" where regno = '" + regno + "'";
            command = new SqlCommand(query, connection2);
            da = new SqlDataAdapter();
            da.SelectCommand = command;
            DataTable dt2 = new DataTable();
            da.Fill(dt2);
            foreach (DataRow row in dt2.Rows)
            {
                for (int i = 1; i < dt2.Columns.Count; i++)
                {
                    String MyStr = Convert.ToString(dt2.Columns[i]);
                    richTextBox1.AppendText(MyStr +" " +row[i].ToString());
                    richTextBox1.AppendText(Environment.NewLine);
                }
            }
            da.Dispose();
        }
    }
}
