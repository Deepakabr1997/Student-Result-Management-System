﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;
using System.Windows.Forms;

namespace prg2
{
    public partial class Form13 : Form
    {
        String str="MCA1";
        SqlConnection sc;
        public Form13()
        {
            InitializeComponent();
        }

        private void Form13_Load(object sender, EventArgs e)
        {
            comboBox1.Items.Add("MCA");
            comboBox1.Items.Add("MSC");
            comboBox2.Items.Add("1");
            comboBox2.Items.Add("2");
            comboBox4.Items.Add("MCA");
            comboBox4.Items.Add("MSC");
            comboBox3.Items.Add("1");
            comboBox3.Items.Add("2");
            DataRow dr;
            sc = new SqlConnection();
            sc.ConnectionString = (@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Admin\source\repos\prg2\prg2\Project.mdf;Integrated Security=True");
            sc.Open();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            str = "";
            str = comboBox1.Text + comboBox2.Text;
            update();
        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            str = "";
            str = comboBox1.Text + comboBox2.Text;
            update();

        }

        private void button3_Click(object sender, EventArgs e)
        {
            str = "";
            str = comboBox1.Text + comboBox2.Text;
            SqlCommand cd = new SqlCommand("Delete from "+ str + " where regno='" + textBox2.Text + "'", sc);
            cd.ExecuteNonQuery();
            update();
            sc.Close();
        }

        private void comboBox4_SelectedIndexChanged(object sender, EventArgs e)
        {
            str = "";
            str = comboBox4.Text + comboBox3.Text;
            update();
            update2();
        }

        private void comboBox3_SelectedIndexChanged(object sender, EventArgs e)
        {
            str = "";
            str = comboBox4.Text + comboBox3.Text;
            update();
            update2();
        }

        private void update()
        {
            try
            {
                SqlCommand cmd = new SqlCommand("select * from " + str + "", sc);
                SqlDataAdapter sda = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                sda.Fill(dt);
                dataGridView1.DataSource = dt;
            }
            catch { }
        }
        private void update2()
        {
            string cmdstr = @"select * from information_schema.columns where table_name = '" + str + "' and column_name <> 'regno'";
            DataTable dt1 = new DataTable();
            SqlDataAdapter sda = new SqlDataAdapter(cmdstr, sc);
            sda.Fill(dt1);
            comboBox5.DataSource = dt1;
            comboBox5.DisplayMember = "Column_Name";
        }

        private void button1_Click(object sender, EventArgs e)
        {
            textBox4.Text = comboBox5.Text;
            SqlCommand com = new SqlCommand();
            com.Connection = sc;
            com.CommandText = ("UPDATE "+ str +" SET "+textBox4.Text+" = " + textBox3.Text + " WHERE regno= "+textBox1.Text+";");
            com.ExecuteNonQuery();
            update();
            sc.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form4 f4 = new Form4();
            f4.ShowDialog();
        }
    }
}
