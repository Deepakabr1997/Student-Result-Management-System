﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;
using System.Windows.Forms;

namespace prg2
{
    public partial class Form7 : Form
    {
        SqlConnection sc;
        public Form7()
        {
            InitializeComponent();
        }

        private void Form7_Load(object sender, EventArgs e)
        {
            richTextBox1.Text = "Reminder";
        }

        private void button3_Click(object sender, EventArgs e)
        {
            string rdate = monthCalendar1.SelectionRange.Start.ToShortDateString();
            string ndate = DateTime.UtcNow.ToString("d");
            sc = new SqlConnection();
            sc.ConnectionString = (@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Admin\source\repos\prg2\prg2\Project.mdf;Integrated Security=True");
            sc.Open();
            if (rdate == ndate)
            {
                MessageBox.Show("Reminder is for today");
            }
            String query = @"INSERT INTO Reminder VALUES('" + rdate + "','" + richTextBox1.Text + "'); ";
            SqlCommand cmd2 = new SqlCommand(query, sc);
            cmd2.ExecuteNonQuery();
            MessageBox.Show("Reminder Added Successfully Successfully");
            sc.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form4 f4 = new Form4();
            f4.ShowDialog();
        }
    }
}
