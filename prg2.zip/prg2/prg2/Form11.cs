﻿using System;
using System.IO;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Text.RegularExpressions;

namespace prg2
{

    public partial class Form11 : Form
    {
        Image file;
        byte[] pic;
        string regno;

        public Form11(string str)
        {
            InitializeComponent();
            regno = str;
        }

        byte[] ConvertImageToBytes(Image img)
        {
            using (MemoryStream ms = new MemoryStream())
            {
                img.Save(ms, System.Drawing.Imaging.ImageFormat.Png);
                return ms.ToArray();
            }
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            OpenFileDialog f = new OpenFileDialog();
            f.Filter = "JPG (*.JPG)|*.jpg";
            if (f.ShowDialog() == DialogResult.OK)
            {
                file = Image.FromFile(f.FileName);
                pictureBox1.Image = file;
                pic = ConvertImageToBytes(file);
                pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            }
        }

        private void dateTimePicker1_ValueChanged_1(object sender, EventArgs e)
        {
            //Calculate the current age of the person
            DateTime from = dateTimePicker1.Value;
            DateTime to = DateTime.Now;
            TimeSpan tSpan = to - from;
            double days = tSpan.TotalDays;
            textBox2.Text = ((days / 365).ToString("0"));
        }

        private void txtEmail_Leave_1(object sender, EventArgs e)
        {
            //Check for valid email format
            Regex mRegxExpression;
            if (txtEmail.Text.Trim() != string.Empty)
            {
                mRegxExpression = new Regex(@"^([a-zA-Z0-9_\-])([a-zA-Z0-9_\-\.]*)@(\[((25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\.){3}|((([a-zA-Z0-9\-]+)\.)+))([a-zA-Z]{2,}|(25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\])$");

                if (!mRegxExpression.IsMatch(txtEmail.Text.Trim()))
                {
                    MessageBox.Show("E-mail address format is not correct.", "Unified", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    txtEmail.Focus();
                }

            }
        }

        private void btnSave_Click_1(object sender, EventArgs e)
        {
            int age;
            age = Convert.ToInt32(textBox2.Text);
            String gender;
            if (radioButton1.Checked == true)
            {
                gender = "female";
            }
            else
            {
                gender = "male";
            }
            Regex r = new Regex("^[a-zA-Z ]+$");
            if (txtId.Text.Trim() == string.Empty || txtFname.Text.Trim() == string.Empty || richTextBox1.Text.Trim() == string.Empty || txtEmail.Text.Trim() == string.Empty || textBox1.Text.Trim() == string.Empty || password1.Text.Trim() == string.Empty || textBox3.Text.Trim() == string.Empty)
            {
                MessageBox.Show("Please fill out the fields", "Unified", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else if (!r.IsMatch(txtFname.Text))
            {
                // first name was incorrect  
                MessageBox.Show("Invalid Name", "Unified", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else if ((radioButton1.Checked == false) && (radioButton2.Checked == false))
            {
                MessageBox.Show("Please Check a Radio Button", "Unified", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else if ((comboBox1.SelectedIndex == -1) || (comboBoxState.SelectedIndex == -1) || (comboBoxCity.SelectedIndex == -1))
            {
                MessageBox.Show("Please make selection in all combo boxes", "Unified", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            //Check if mobile number is valid or not
            else if (!Regex.Match(textBox1.Text, "^[0-9]{10}").Success)
            {
                MessageBox.Show("Invalid phone format", "Unified", MessageBoxButtons.OK, MessageBoxIcon.Error);
                textBox1.Focus();
            }
            else if (age < 18)
            {
                MessageBox.Show("Under Age Criteria", "Unified", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else if (password1.Text != textBox3.Text)
            {
                MessageBox.Show("Passwords doesnt match", "Unified", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                SqlConnection sc = new SqlConnection();
                SqlCommand com = new SqlCommand();
                sc.ConnectionString = (@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Admin\source\repos\prg2\prg2\Project.mdf;Integrated Security=True");
                sc.Open();
                com.Connection = sc;
                com.CommandText = ("UPDATE Data SET name='" + txtFname.Text + "',Course='" + comboBox1.Text + "',Semester='" + numericUpDown1.Text + "',dob='" + dateTimePicker1.Text + "',gender='" + gender + "',address='" + richTextBox1.Text + "',state='" + comboBoxState.Text + "',city='" + comboBoxCity.Text + "',email='" + txtEmail.Text + "',mobile='" + textBox1.Text + "',password='" + password1.Text + "',image= @image WHERE regno='" + txtId.Text + "';");
                com.Parameters.AddWithValue("@image", pic);
                com.ExecuteNonQuery();
                sc.Close();
                MessageBox.Show("Updation Successful!", "Unified", MessageBoxButtons.OK, MessageBoxIcon.None);
            }
        }

        private void btnClear_Click_1(object sender, EventArgs e)
        {
            txtId.Clear();
            txtFname.Clear();
            radioButton1.Checked = false;
            radioButton2.Checked = false;
            richTextBox1.Clear();
            comboBoxState.Items[comboBoxState.SelectedIndex] = string.Empty;
            comboBoxCity.Items[comboBoxCity.SelectedIndex] = string.Empty;
            comboBox1.Items[comboBox1.SelectedIndex] = string.Empty;
            txtEmail.Clear();
            textBox1.Clear();
            textBox3.Clear();
            password1.Clear();
        }

        private void btnCancel_Click_1(object sender, EventArgs e)
        {
            String email="";
            SqlCommand command;
            SqlDataAdapter da;
            SqlConnection connection = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Admin\source\repos\prg2\prg2\Project.mdf;Integrated Security=True");
            String query = "Select email from Data where regno='" + regno + "';";
            command = new SqlCommand(query, connection);
            da = new SqlDataAdapter();
            da.SelectCommand = command;
            DataTable dt = new DataTable();
            da.Fill(dt);
            foreach (DataRow row in dt.Rows)
            {
                email = (string)row[0];
            }
            da.Dispose();
            this.Hide();
            Form8 f8 = new Form8(email);
            f8.ShowDialog();
        }

        private void Form11_Load_1(object sender, EventArgs e)
        {
            txtId.Text = regno;
            txtId.Enabled = false;
            comboBox1.Items.Add("MCA");
            comboBox1.Items.Add("MSC");
            comboBox1.SelectedIndex = -1;
            comboBoxState.SelectedIndex = -1;
            comboBoxCity.SelectedIndex = -1;
            textBox2.Enabled = false;
        }
    }
}

