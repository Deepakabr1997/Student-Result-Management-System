﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace prg2
{
    public partial class Form6 : Form
    {
        int x;
        string str,i;
        SqlConnection sc;
        public Form6()
        {
            InitializeComponent();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            str = "";
            str = comboBox1.Text + comboBox2.Text;
            textBox1.Text = str;
            update1();
            update2();
        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            str = "";
            str = comboBox1.Text + comboBox2.Text;
            textBox1.Text = str;
            update1();
            update2();
        }

        private void Form6_Load(object sender, EventArgs e)
        {
            comboBox1.Items.Add("MCA");
            comboBox1.Items.Add("MSC");
            comboBox2.Items.Add("1");
            comboBox2.Items.Add("2");
            DataRow dr;
            sc = new SqlConnection();
            sc.ConnectionString = (@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Admin\source\repos\prg2\prg2\Project.mdf;Integrated Security=True");
            sc.Open();
            comboBox3.Visible = false;
            textBox3.Visible = false;
            comboBox4.Visible = false;
            textBox4.Visible = false;
            comboBox5.Visible = false;
            textBox5.Visible = false;
            comboBox6.Visible = false;
            textBox6.Visible = false;
            comboBox7.Visible = false;
            textBox7.Visible = false;
            comboBox8.Visible = false;
            textBox8.Visible = false;
            comboBox9.Visible = false;
            textBox9.Visible = false;
            comboBox10.Visible = false;
            textBox10.Visible = false;
            textBox11.Enabled = false;
            textBox12.Enabled = false;
        }
        void update1()
        {
            string cmdstr = @"select * from information_schema.columns where table_name = '" + str + "' and column_name <> 'regno'";
            DataTable dt1 = new DataTable();
            SqlDataAdapter sda = new SqlDataAdapter(cmdstr, sc);
            sda.Fill(dt1);
            comboBox3.DataSource = dt1;
            comboBox3.DisplayMember = "Column_Name";
            DataTable dt2 = new DataTable();
            sda.Fill(dt2);
            comboBox4.DataSource = dt2;
            comboBox4.DisplayMember = "Column_Name";
            DataTable dt3 = new DataTable();
            sda.Fill(dt3);
            comboBox5.DataSource = dt3;
            comboBox5.DisplayMember = "Column_Name";
            DataTable dt4 = new DataTable();
            sda.Fill(dt4);
            comboBox6.DataSource = dt4;
            comboBox6.DisplayMember = "Column_Name";
            DataTable dt5 = new DataTable();
            sda.Fill(dt5);
            comboBox7.DataSource = dt5;
            comboBox7.DisplayMember = "Column_Name";
            DataTable dt6 = new DataTable();
            sda.Fill(dt6);
            comboBox7.DataSource = dt6;
            comboBox7.DisplayMember = "Column_Name";
            DataTable dt7 = new DataTable();
            sda.Fill(dt7);
            comboBox8.DataSource = dt7;
            comboBox8.DisplayMember = "Column_Name";
            DataTable dt8 = new DataTable();
            sda.Fill(dt8);
            comboBox9.DataSource = dt8;
            comboBox9.DisplayMember = "Column_Name";
            DataTable dt9 = new DataTable();
            sda.Fill(dt9);
            comboBox10.DataSource = dt9;
            comboBox10.DisplayMember = "Column_Name";
        }
        void update2()
        {
            comboBox3.Visible = false;
            textBox3.Visible = false;
            comboBox4.Visible = false;
            textBox4.Visible = false;
            comboBox5.Visible = false;
            textBox5.Visible = false;
            comboBox6.Visible = false;
            textBox6.Visible = false;
            comboBox7.Visible = false;
            textBox7.Visible = false;
            comboBox8.Visible = false;
            textBox8.Visible = false;
            comboBox9.Visible = false;
            textBox9.Visible = false;
            comboBox10.Visible = false;
            textBox10.Visible = false;
            i = comboBox3.Items.Count.ToString();
            x = int.Parse(i);
            if (x > 8)
            {
                MessageBox.Show("Only maximum 8 marks can be entered");
            }
            else
            {
                if (x >= 8)
                {
                    comboBox10.Visible = true;
                    textBox10.Visible = true;
                }
                if (x >= 7)
                {
                    comboBox9.Visible = true;
                    textBox9.Visible = true;
                }
                if (x >= 6)
                {
                    comboBox8.Visible = true;
                    textBox8.Visible = true;
                }
                if (x >= 5)
                {
                    comboBox7.Visible = true;
                    textBox7.Visible = true;
                }
                if (x >= 4)
                {
                    comboBox6.Visible = true;
                    textBox6.Visible = true;
                }
                if (x >= 3)
                {
                    comboBox5.Visible = true;
                    textBox5.Visible = true;
                }
                if (x >= 2)
                {
                    comboBox4.Visible = true;
                    textBox4.Visible = true;
                }
                if (x >= 1)
                {
                    comboBox3.Visible = true;
                    textBox3.Visible = true;
                }
            }


        }
        private void button2_Click(object sender, EventArgs e)
        {
            string query="";
            str = "";
            str = comboBox1.Text + comboBox2.Text;
            textBox1.Text = str;
            if (x == 1)
                query = @"INSERT INTO " + textBox1.Text + "(regno," + comboBox3.Text + ") VALUES('" + textBox2.Text + "','" + textBox3.Text + "'); ";
            else if (x == 2)
                query = @"INSERT INTO " + textBox1.Text + "(regno," + comboBox3.Text + "," + comboBox4.Text + ") VALUES('" + textBox2.Text + "','" + textBox3.Text + "','" + textBox4.Text + "'); ";
            else if (x == 3)
                query = @"INSERT INTO " + textBox1.Text + "(regno," + comboBox3.Text + "," + comboBox4.Text + "," + comboBox5.Text + ") VALUES('" + textBox2.Text + "','" + textBox3.Text + "','" + textBox4.Text + "','" + textBox5.Text + "'); ";
            else if (x == 4)
                query = @"INSERT INTO " + textBox1.Text + "(regno," + comboBox3.Text + "," + comboBox4.Text + "," + comboBox5.Text + "," + comboBox6.Text + ") VALUES('" + textBox2.Text + "','" + textBox3.Text + "','" + textBox4.Text + "','" + textBox5.Text + "','" + textBox6.Text + "'); ";
            else if (x == 5)
                query = @"INSERT INTO " + textBox1.Text + "(regno," + comboBox3.Text + "," + comboBox4.Text + "," + comboBox5.Text + "," + comboBox6.Text + "," + comboBox7.Text + ") VALUES('" + textBox2.Text + "','" + textBox3.Text + "','" + textBox4.Text + "','" + textBox5.Text + "','" + textBox6.Text + "','" + textBox7.Text + "'); ";
            else if (x == 6)
                query = @"INSERT INTO " + textBox1.Text + "(regno," + comboBox3.Text + "," + comboBox4.Text + "," + comboBox5.Text + "," + comboBox6.Text + "," + comboBox7.Text + "," + comboBox8.Text + ") VALUES('" + textBox2.Text + "','" + textBox3.Text + "','" + textBox4.Text + "','" + textBox5.Text + "','" + textBox6.Text + "','" + textBox7.Text + "','" + textBox8.Text + "'); ";
            else if (x == 7)
                query = @"INSERT INTO " + textBox1.Text + "(regno," + comboBox3.Text + "," + comboBox4.Text + "," + comboBox5.Text + "," + comboBox6.Text + "," + comboBox7.Text + "," + comboBox8.Text + "," + comboBox9.Text + ") VALUES('" + textBox2.Text + "','" + textBox3.Text + "','" + textBox4.Text + "','" + textBox5.Text + "','" + textBox6.Text + "','" + textBox7.Text + "','" + textBox8.Text + "','" + textBox9.Text + "'); ";
            else if (x == 8)
                query = @"INSERT INTO " + textBox1.Text + "(regno," + comboBox3.Text + "," + comboBox4.Text + "," + comboBox5.Text + "," + comboBox6.Text + "," + comboBox7.Text + "," + comboBox8.Text + "," + comboBox9.Text + "," + comboBox10.Text + ") VALUES('" + textBox2.Text + "','" + textBox3.Text + "','" + textBox4.Text + "','" + textBox5.Text + "','" + textBox6.Text + "','" + textBox7.Text + "','" + textBox8.Text + "','" + textBox9.Text + "','" + textBox10.Text + "'); ";
            else
                MessageBox.Show("Please make the selections");
            SqlCommand cmd2 = new SqlCommand(query, sc);
            cmd2.ExecuteNonQuery();
            MessageBox.Show("Marks Added Successfully Successfully");
        }

        private void textBox3_KeyPress(object sender, KeyPressEventArgs e)
        {
            char ch = e.KeyChar;
            if (!Char.IsDigit(ch) && ch != 8 && ch != 46)
                e.Handled = true;
        }

        private void textBox4_KeyPress(object sender, KeyPressEventArgs e)
        {
            char ch = e.KeyChar;
            if (!Char.IsDigit(ch) && ch != 8 && ch != 46)
                e.Handled = true;

        }

        private void textBox5_KeyPress(object sender, KeyPressEventArgs e)
        {
            char ch = e.KeyChar;
            if (!Char.IsDigit(ch) && ch != 8 && ch != 46)
                e.Handled = true;

        }

        private void textBox6_KeyPress(object sender, KeyPressEventArgs e)
        {
            char ch = e.KeyChar;
            if (!Char.IsDigit(ch) && ch != 8 && ch != 46)
                e.Handled = true;

        }

        private void textBox7_KeyPress(object sender, KeyPressEventArgs e)
        {
            char ch = e.KeyChar;
            if (!Char.IsDigit(ch) && ch != 8 && ch != 46)
                e.Handled = true;

        }

        private void textBox8_KeyPress(object sender, KeyPressEventArgs e)
        {
            char ch = e.KeyChar;
            if (!Char.IsDigit(ch) && ch != 8 && ch != 46)
                e.Handled = true;

        }

        private void textBox9_KeyPress(object sender, KeyPressEventArgs e)
        {
            char ch = e.KeyChar;
            if (!Char.IsDigit(ch) && ch != 8 && ch != 46)
                e.Handled = true;

        }

        private void button1_Click(object sender, EventArgs e)
        {
            double mark1=0,mark2=0,mark3=0,mark4=0,mark5=0,mark6=0,mark7=0,mark8=0,sum=0,avg=0;
            if (x >= 1)
                mark1 = double.Parse(textBox3.Text);
            if (x >= 2)
                mark2 = double.Parse(textBox4.Text);
            if (x >= 3)
                mark3 = double.Parse(textBox5.Text);
            if (x >= 4)
                mark4 = double.Parse(textBox6.Text);
            if (x >= 5)
                mark5 = double.Parse(textBox7.Text);
            if (x >= 6)
                mark6 = double.Parse(textBox8.Text);
            if (x >= 7)
                mark7 = double.Parse(textBox9.Text);
            if (x >= 8)
                mark8 = double.Parse(textBox10.Text);
            /*
            if (textBox3.Text == "")
                mark1 = 0;
            if (textBox4.Text == "")
                mark2 = 0;
            if (textBox5.Text == "")
                mark3 = 0;
            if (textBox6.Text == "")
                mark4 = 0;
            */
            sum = mark1 + mark2 + mark3 + mark4+ mark5 + mark6 + mark7 + mark8;
            avg = (sum / (x * 100)) * 100;
            textBox11.Text = sum.ToString();
            textBox12.Text = avg.ToString();

        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form4 f4 = new Form4();
            f4.ShowDialog();

        }

        private void textBox10_KeyPress(object sender, KeyPressEventArgs e)
        {
            char ch = e.KeyChar;
            if (!Char.IsDigit(ch) && ch != 8 && ch != 46)
                e.Handled = true;

        }
    }
}
