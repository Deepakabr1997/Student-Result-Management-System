﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Windows.Forms;
using System.IO;

namespace prg2
{
    public partial class Form8 : Form
    {
        string regno;
        SqlConnection connection = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Admin\source\repos\prg2\prg2\Project.mdf;Integrated Security=True");
        SqlCommand command;
        SqlDataAdapter da;
        public Form8()
        {
            InitializeComponent();
        }
        public Form8(String str)
        {
            InitializeComponent();
            label1.Text = "Welcome " + str;
            String query = "Select * from Data where email='"+str+"'";
            command = new SqlCommand(query, connection);
            da = new SqlDataAdapter();
            da.SelectCommand = command;
            DataTable dt = new DataTable();
            da.Fill(dt);
            foreach(DataRow row in dt.Rows)
            {
                regno = (string)row[0];
                MemoryStream ms = new MemoryStream((byte[])row[12]);
                pictureBox1.Image = Image.FromStream(ms);
            }
            da.Dispose();
        }
        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form9 f9 = new Form9(regno);
            f9.ShowDialog();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form11 f11 = new Form11(regno);
            f11.ShowDialog();
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            this.Hide();
            Form2 f2 = new Form2();
            f2.ShowDialog();
        }
    }
}
