﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace prg2
{
    public partial class Form5 : Form
    {
        string str;
        SqlConnection sc;
        public Form5()
        {
            InitializeComponent();
        }

        private void Form5_Load(object sender, EventArgs e)
        {
            comboBox1.Items.Add("MCA");
            comboBox1.Items.Add("MSC");
            comboBox2.Items.Add("1");
            comboBox2.Items.Add("2");
            DataRow dr;
            sc = new SqlConnection();
            sc.ConnectionString = (@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Admin\source\repos\prg2\prg2\Project.mdf;Integrated Security=True");
            sc.Open();
        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            str= "";
            str = comboBox1.Text + comboBox2.Text;
            textBox1.Text = str;
            update1();
            update3();
            /*string cmdstr = @"select * from information_schema.columns where table_name = '" + str + "' and column_name <> 'regno'";
            DataTable dt = new DataTable();
            SqlDataAdapter sda = new SqlDataAdapter(cmdstr, sc);
            sda.Fill(dt);
            listBox1.DataSource = dt;
            listBox1.DisplayMember = "Column_Name";*/
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            str = "";
            str = comboBox1.Text + comboBox2.Text;
            textBox1.Text = str;
            update1();
            update3();
            /*string cmdstr = @"select * from information_schema.columns where table_name = '" + str + "' and column_name <> 'regno'";
            DataTable dt = new DataTable();
            SqlDataAdapter sda = new SqlDataAdapter(cmdstr, sc);
            sda.Fill(dt);
            listBox1.DataSource = dt;
            listBox1.DisplayMember = "Column_Name";*/
        }

        private void button3_Click(object sender, EventArgs e)
        {
            str = "";
            str = comboBox1.Text + comboBox2.Text;
            textBox1.Text = str;
            string query =@"ALTER TABLE "+str+" ADD " + textBox2.Text +" numeric(18,0) NULL;";
            SqlCommand cmd2 = new SqlCommand(query, sc);
            cmd2.ExecuteNonQuery();
            MessageBox.Show("Item Added Successfully");
            update1();
            update3();
        }

        void update1()
        {
            string cmdstr = @"select * from information_schema.columns where table_name = '" + str + "' and column_name <> 'regno'";
            DataTable dt = new DataTable();
            SqlDataAdapter sda = new SqlDataAdapter(cmdstr, sc);
            sda.Fill(dt);
            listBox1.DataSource = dt;
            listBox1.DisplayMember = "Column_Name";
        }
        void update3()
        {
            string cmdstr = @"select * from information_schema.columns where table_name = '" + str + "' and column_name <> 'regno'";
            DataTable dt = new DataTable();
            SqlDataAdapter sda = new SqlDataAdapter(cmdstr, sc);
            sda.Fill(dt);
            listBox3.DataSource = dt;
            listBox3.DisplayMember = "Column_Name";
        }

        private void button4_Click(object sender, EventArgs e)
        {
            str = "";
            str = comboBox1.Text + comboBox2.Text;
            textBox1.Text = str;
            string query = @"ALTER TABLE " + str + " DROP COLUMN " + textBox3.Text + ";";
            SqlCommand cmd2 = new SqlCommand(query,sc);
            cmd2.ExecuteNonQuery();
            MessageBox.Show("Item Removed Successfully");
            update1();
            update3();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            sc.Close();
            this.Hide();
            Form4 f4 = new Form4();
            f4.Show();
        }
    }
}
