﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using System.IO;

namespace prg2
{
    public partial class Form3 : Form
    {
        Image file;
        byte[] pic;
        public Form3()
        {
            InitializeComponent();
        }

        private void txtId_TextChanged(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {

        }
        byte[] ConvertImageToBytes(Image img)
        {
            using (MemoryStream ms = new MemoryStream())
            {
                img.Save(ms, System.Drawing.Imaging.ImageFormat.Png);
                return ms.ToArray();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            OpenFileDialog f = new OpenFileDialog();
            f.Filter = "JPG (*.JPG)|*.jpg";
            if (f.ShowDialog() == DialogResult.OK)
            {
                file = Image.FromFile(f.FileName);
                pictureBox1.Image = file;
                pic=ConvertImageToBytes(file);
                pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            }
        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {
            //Calculate the current age of the person
            DateTime from = dateTimePicker1.Value;
            DateTime to = DateTime.Now;
            TimeSpan tSpan = to - from;
            double days = tSpan.TotalDays;
            textBox2.Text = ((days / 365).ToString("0"));
        }

        private void txtEmail_Leave(object sender, EventArgs e)
        {
            //Check for valid email format
            Regex mRegxExpression;
            if (txtEmail.Text.Trim() != string.Empty)
            {
                mRegxExpression = new Regex(@"^([a-zA-Z0-9_\-])([a-zA-Z0-9_\-\.]*)@(\[((25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\.){3}|((([a-zA-Z0-9\-]+)\.)+))([a-zA-Z]{2,}|(25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\])$");

                if (!mRegxExpression.IsMatch(txtEmail.Text.Trim()))
                {
                    MessageBox.Show("E-mail address format is not correct.", "Unified", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    txtEmail.Focus();
                }

            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            
            
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            int age;
            age=Convert.ToInt32(textBox2.Text);
            String gender;
            if (radioButton1.Checked == true)
            {
                gender = "female";
            }
            else
            {
                gender = "male";
            }
            Regex r = new Regex("^[a-zA-Z ]+$");
            if (txtId.Text.Trim() == string.Empty || txtFname.Text.Trim() == string.Empty || richTextBox1.Text.Trim() == string.Empty || txtEmail.Text.Trim() == string.Empty || textBox1.Text.Trim() == string.Empty || password1.Text.Trim() == string.Empty || textBox3.Text.Trim() == string.Empty)
            {
                MessageBox.Show("Please fill out the fields", "Unified", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else if (!r.IsMatch(txtFname.Text))
            {
                // first name was incorrect  
                MessageBox.Show("Invalid Name", "Unified", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else if ((radioButton1.Checked==false) && (radioButton2.Checked == false))
            {
                MessageBox.Show("Please Check a Radio Button", "Unified", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else if((comboBox1.SelectedIndex==-1) || (comboBoxState.SelectedIndex==-1) || (comboBoxCity.SelectedIndex == -1))
            {
                MessageBox.Show("Please make selection in all combo boxes", "Unified", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            //Check if mobile number is valid or not
            else if (!Regex.Match(textBox1.Text, "^[0-9]{10}").Success)
            {
                MessageBox.Show("Invalid phone format", "Unified", MessageBoxButtons.OK, MessageBoxIcon.Error);
                textBox1.Focus();
            }
            else if(age<18)
            {
                MessageBox.Show("Under Age Criteria", "Unified", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else if(password1.Text!=textBox3.Text)
            {
                MessageBox.Show("Passwords doesnt match", "Unified", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                SqlConnection sc = new SqlConnection();
                SqlCommand com = new SqlCommand();
                sc.ConnectionString = (@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Admin\source\repos\prg2\prg2\Project.mdf;Integrated Security=True");
                sc.Open();
                com.Connection = sc;
                com.CommandText = ("INSERT INTO Data(regno,name,Course,Semester,dob,gender,address,state,city,email,mobile,password,image) VALUES('" + txtId.Text + "','" + txtFname.Text + "','" + comboBox1.Text + "','" + numericUpDown1.Text + "','" + dateTimePicker1.Text + "','" + gender + "','" + richTextBox1.Text + "','" + comboBoxState.Text + "','" + comboBoxCity.Text + "','" + txtEmail.Text + "','" + textBox1.Text + "','" + textBox3.Text + "',@image);");
                com.Parameters.AddWithValue("@image", pic);
                com.ExecuteNonQuery();
                sc.Close();
                MessageBox.Show("Registration Successful!", "Unified", MessageBoxButtons.OK, MessageBoxIcon.None);
            }
        }

        private void Form3_Load(object sender, EventArgs e)
        {
            comboBox1.Items.Add("MCA");
            comboBox1.Items.Add("MSC");
            comboBox1.SelectedIndex = -1;
            comboBoxState.SelectedIndex = -1;
            comboBoxCity.SelectedIndex = -1;
            textBox2.Enabled = false;
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            txtId.Clear();
            txtFname.Clear();
            radioButton1.Checked = false;
            radioButton2.Checked = false;
            richTextBox1.Clear();
            comboBoxState.Items[comboBoxState.SelectedIndex] = string.Empty;
            comboBoxCity.Items[comboBoxCity.SelectedIndex] = string.Empty;
            comboBox1.Items[comboBox1.SelectedIndex] = string.Empty;
            txtEmail.Clear();
            textBox1.Clear();
            textBox3.Clear();
            password1.Clear();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form2 f2 = new Form2();
            f2.ShowDialog();
        }
    }
}
